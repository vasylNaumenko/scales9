-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.50 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win64
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры базы данных game
CREATE DATABASE IF NOT EXISTS `game` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `game`;


-- Дамп структуры для таблица game.data
DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) unsigned DEFAULT '0',
  `game_data` text,
  PRIMARY KEY (`id`),
  KEY `game_id` (`game_id`),
  CONSTRAINT `game_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы game.data: ~10 rows (приблизительно)
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
INSERT INTO `data` (`id`, `game_id`, `game_data`) VALUES
	(17, 18, '{"selected":"4","scale_one":{"groups":{"group_1":{"items":{"5":0,"7":0,"6":0},"weight":0},"group_2":{"items":{"4":1,"8":0,"1":0},"weight":1},"group_3":{"items":{"2":0,"9":0,"3":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"4":1,"8":0,"1":0}},"scale_two":{"groups":{"group_1":{"items":{"4":1},"weight":1},"group_2":{"items":{"8":0},"weight":0},"group_3":{"items":{"1":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"4":1}},"result":4}'),
	(18, 19, '{"selected":"3","scale_one":{"groups":{"group_1":{"items":{"1":0,"3":1,"6":0},"weight":1},"group_2":{"items":{"2":0,"8":0,"5":0},"weight":0},"group_3":{"items":{"7":0,"9":0,"4":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"1":0,"3":1,"6":0}},"scale_two":{"groups":{"group_1":{"items":{"1":0},"weight":0},"group_2":{"items":{"3":1},"weight":1},"group_3":{"items":{"6":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"3":1}},"result":3}'),
	(19, 20, '{"selected":"1","scale_one":{"groups":{"group_1":{"items":{"9":0,"7":0,"4":0},"weight":0},"group_2":{"items":{"1":1,"8":0,"2":0},"weight":1},"group_3":{"items":{"5":0,"3":0,"6":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"1":1,"8":0,"2":0}},"scale_two":{"groups":{"group_1":{"items":{"1":1},"weight":1},"group_2":{"items":{"8":0},"weight":0},"group_3":{"items":{"2":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"1":1}},"result":1}'),
	(20, 21, '{"selected":"9","scale_one":{"groups":{"group_1":{"items":{"5":0,"1":0,"6":0},"weight":0},"group_2":{"items":{"9":1,"8":0,"7":0},"weight":1},"group_3":{"items":{"4":0,"3":0,"2":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"9":1,"8":0,"7":0}},"scale_two":{"groups":{"group_1":{"items":{"9":1},"weight":1},"group_2":{"items":{"8":0},"weight":0},"group_3":{"items":{"7":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"9":1}},"result":9}'),
	(21, 22, '{"selected":"8","scale_one":{"groups":{"group_1":{"items":{"5":0,"6":0,"9":0},"weight":0},"group_2":{"items":{"3":0,"4":0,"2":0},"weight":0},"group_3":{"items":{"1":0,"8":1,"7":0},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"1":0,"8":1,"7":0}},"scale_two":{"groups":{"group_1":{"items":{"1":0},"weight":0},"group_2":{"items":{"8":1},"weight":1},"group_3":{"items":{"7":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"8":1}},"result":8}'),
	(22, 23, '{"selected":"1","scale_one":{"groups":{"group_1":{"items":{"7":0,"9":0,"1":1},"weight":1},"group_2":{"items":{"4":0,"2":0,"3":0},"weight":0},"group_3":{"items":{"6":0,"8":0,"5":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"7":0,"9":0,"1":1}},"scale_two":{"groups":{"group_1":{"items":{"7":0},"weight":0},"group_2":{"items":{"9":0},"weight":0},"group_3":{"items":{"1":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"1":1}},"result":1}'),
	(23, 24, '{"selected":"2","scale_one":{"groups":{"group_1":{"items":{"7":0,"6":0,"1":0},"weight":0},"group_2":{"items":{"9":0,"5":0,"3":0},"weight":0},"group_3":{"items":{"8":0,"4":0,"2":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"8":0,"4":0,"2":1}},"scale_two":{"groups":{"group_1":{"items":{"8":0},"weight":0},"group_2":{"items":{"4":0},"weight":0},"group_3":{"items":{"2":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"2":1}},"result":2}'),
	(24, 25, '{"selected":"5","scale_one":{"groups":{"group_1":{"items":{"7":0,"6":0,"1":0},"weight":0},"group_2":{"items":{"4":0,"8":0,"9":0},"weight":0},"group_3":{"items":{"3":0,"2":0,"5":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"3":0,"2":0,"5":1}},"scale_two":{"groups":{"group_1":{"items":{"3":0},"weight":0},"group_2":{"items":{"2":0},"weight":0},"group_3":{"items":{"5":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"5":1}},"result":5}'),
	(25, 26, '{"selected":"3","scale_one":{"groups":{"group_1":{"items":{"4":0,"1":0,"7":0},"weight":0},"group_2":{"items":{"2":0,"9":0,"6":0},"weight":0},"group_3":{"items":{"5":0,"8":0,"3":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"5":0,"8":0,"3":1}},"scale_two":{"groups":{"group_1":{"items":{"5":0},"weight":0},"group_2":{"items":{"8":0},"weight":0},"group_3":{"items":{"3":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"3":1}},"result":3}'),
	(26, 27, '{"selected":"2","scale_one":{"groups":{"group_1":{"items":{"6":0,"1":0,"7":0},"weight":0},"group_2":{"items":{"9":0,"3":0,"4":0},"weight":0},"group_3":{"items":{"5":0,"2":1,"8":0},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"5":0,"2":1,"8":0}},"scale_two":{"groups":{"group_1":{"items":{"5":0},"weight":0},"group_2":{"items":{"2":1},"weight":1},"group_3":{"items":{"8":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"2":1}},"result":2}'),
	(27, 28, '{"selected":"1","scale_one":{"groups":{"group_1":{"items":{"3":0,"5":0,"2":0},"weight":0},"group_2":{"items":{"9":0,"4":0,"8":0},"weight":0},"group_3":{"items":{"1":1,"6":0,"7":0},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"1":1,"6":0,"7":0}},"scale_two":{"groups":{"group_1":{"items":{"1":1},"weight":1},"group_2":{"items":{"6":0},"weight":0},"group_3":{"items":{"7":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"1":1}},"result":1}'),
	(28, 29, '{"selected":"2","scale_one":{"groups":{"group_1":{"items":{"3":0,"7":0,"1":0},"weight":0},"group_2":{"items":{"2":1,"8":0,"9":0},"weight":1},"group_3":{"items":{"5":0,"4":0,"6":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"2":1,"8":0,"9":0}},"scale_two":{"groups":{"group_1":{"items":{"2":1},"weight":1},"group_2":{"items":{"8":0},"weight":0},"group_3":{"items":{"9":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"2":1}},"result":2}'),
	(29, 30, '{"selected":"9","scale_one":{"groups":{"group_1":{"items":{"7":0,"3":0,"5":0},"weight":0},"group_2":{"items":{"4":0,"6":0,"9":1},"weight":1},"group_3":{"items":{"8":0,"1":0,"2":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"4":0,"6":0,"9":1}},"scale_two":{"groups":{"group_1":{"items":{"4":0},"weight":0},"group_2":{"items":{"6":0},"weight":0},"group_3":{"items":{"9":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"9":1}},"result":9}'),
	(30, 31, '{"selected":"1","scale_one":{"groups":{"group_1":{"items":{"6":0,"5":0,"1":1},"weight":1},"group_2":{"items":{"8":0,"7":0,"4":0},"weight":0},"group_3":{"items":{"2":0,"9":0,"3":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"6":0,"5":0,"1":1}},"scale_two":{"groups":{"group_1":{"items":{"6":0},"weight":0},"group_2":{"items":{"5":0},"weight":0},"group_3":{"items":{"1":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"1":1}},"result":1}'),
	(31, 32, '{"selected":"7","scale_one":{"groups":{"group_1":{"items":{"1":0,"3":0,"5":0},"weight":0},"group_2":{"items":{"4":0,"2":0,"7":1},"weight":1},"group_3":{"items":{"9":0,"8":0,"6":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"4":0,"2":0,"7":1}},"scale_two":{"groups":{"group_1":{"items":{"4":0},"weight":0},"group_2":{"items":{"2":0},"weight":0},"group_3":{"items":{"7":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"7":1}},"result":7}'),
	(32, 33, '{"selected":"9","scale_one":{"groups":{"group_1":{"items":{"8":0,"1":0,"3":0},"weight":0},"group_2":{"items":{"4":0,"2":0,"7":0},"weight":0},"group_3":{"items":{"5":0,"6":0,"9":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"5":0,"6":0,"9":1}},"scale_two":{"groups":{"group_1":{"items":{"5":0},"weight":0},"group_2":{"items":{"6":0},"weight":0},"group_3":{"items":{"9":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"9":1}},"result":9}'),
	(33, 34, '{"selected":"6","scale_one":{"groups":{"group_1":{"items":{"2":0,"8":0,"7":0},"weight":0},"group_2":{"items":{"1":0,"5":0,"6":1},"weight":1},"group_3":{"items":{"3":0,"4":0,"9":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"1":0,"5":0,"6":1}},"scale_two":{"groups":{"group_1":{"items":{"1":0},"weight":0},"group_2":{"items":{"5":0},"weight":0},"group_3":{"items":{"6":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"6":1}},"result":6}'),
	(34, 35, '{"selected":"9","scale_one":{"groups":{"group_1":{"items":{"3":0,"4":0,"2":0},"weight":0},"group_2":{"items":{"6":0,"8":0,"1":0},"weight":0},"group_3":{"items":{"9":1,"7":0,"5":0},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"9":1,"7":0,"5":0}},"scale_two":{"groups":{"group_1":{"items":{"9":1},"weight":1},"group_2":{"items":{"7":0},"weight":0},"group_3":{"items":{"5":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"9":1}},"result":9}'),
	(35, 36, '{"selected":"2","scale_one":{"groups":{"group_1":{"items":{"9":0,"7":0,"6":0},"weight":0},"group_2":{"items":{"1":0,"8":0,"2":1},"weight":1},"group_3":{"items":{"4":0,"5":0,"3":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"1":0,"8":0,"2":1}},"scale_two":{"groups":{"group_1":{"items":{"1":0},"weight":0},"group_2":{"items":{"8":0},"weight":0},"group_3":{"items":{"2":1},"weight":1},"result":"Scale balance. Taking unweighted ball(s)"},"heaviest":{"2":1}},"result":2}'),
	(36, 37, '{"selected":"3","scale_one":{"groups":{"group_1":{"items":{"9":0,"7":0,"2":0},"weight":0},"group_2":{"items":{"3":1,"5":0,"6":0},"weight":1},"group_3":{"items":{"8":0,"4":0,"1":0},"weight":0},"result":"Right scale is heavier"},"heaviest":{"3":1,"5":0,"6":0}},"scale_two":{"groups":{"group_1":{"items":{"3":1},"weight":1},"group_2":{"items":{"5":0},"weight":0},"group_3":{"items":{"6":0},"weight":0},"result":"Left scale is heavier"},"heaviest":{"3":1}},"result":3}');
/*!40000 ALTER TABLE `data` ENABLE KEYS */;


-- Дамп структуры для таблица game.games
DROP TABLE IF EXISTS `games`;
CREATE TABLE IF NOT EXISTS `games` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы game.games: ~10 rows (приблизительно)
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
INSERT INTO `games` (`id`, `name`) VALUES
	(18, 'Ball 4 at 21/10/16 10:32:10'),
	(19, 'Ball 3 at 21/10/16 10:39:10'),
	(20, 'Ball 1 at 21/10/16 10:39:36'),
	(21, 'Ball 9 at 21/10/16 10:42:00'),
	(22, 'Ball 8 at 21/10/16 10:44:27'),
	(23, 'Ball 1 at 21/10/16 10:46:21'),
	(24, 'Ball 2 at 21/10/16 10:48:29'),
	(25, 'Ball 5 at 21/10/16 10:49:20'),
	(26, 'Ball 3 at 21/10/16 10:51:00'),
	(27, 'Ball 2 at 21/10/16 11:19:44'),
	(28, 'Ball 1 at 21/10/16 11:19:47'),
	(29, 'Ball 2 at 21/10/16 11:19:50'),
	(30, 'Ball 9 at 21/10/16 11:19:53'),
	(31, 'Ball 1 at 21/10/16 11:19:59'),
	(32, 'Ball 7 at 21/10/16 11:22:28'),
	(33, 'Ball 9 at 21/10/16 11:22:32'),
	(34, 'Ball 6 at 21/10/16 11:22:35'),
	(35, 'Ball 9 at 21/10/16 11:22:38'),
	(36, 'Ball 2 at 21/10/16 11:22:41'),
	(37, 'Ball 3 at 21/10/16 11:22:44');
/*!40000 ALTER TABLE `games` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
